//Mateus Martins Nicolussi Cód.:831823
package Biblioteca;

import java.time.LocalDate;

public class Emprestimo extends Livro{
    //Declarção das Variáveis.
    private int idEmp;
    private int idUsuario;
    private int idLivro;
    private LocalDate dataEmprestimo;
    private LocalDate dataDevolucao;
    public static String devolvido;
    //Criação dos contrutores(Vazio e sobrecarregado)
    public Emprestimo() {
    }
    public Emprestimo(int idEmp, int idUsuario, int idLivro, LocalDate dataEmprestimo, LocalDate dataDevolucao, String devolvido) {
        this.idEmp = idEmp;
        this.idUsuario = idUsuario;
        this.idLivro = idLivro;
        this.dataEmprestimo = dataEmprestimo;
        this.dataDevolucao = dataDevolucao;
        this.devolvido = devolvido;
    }
    //Declaração dos getters e setters
    public int getIdEmp() {
        return idEmp;
    }
    public void setIdEmp(int idEmp) {
        this.idEmp = idEmp;
    }
    public int getIdUsuario() {
        return idUsuario;
    }
    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }
    public int getIdLivro() {
        return idLivro;
    }
    public void setIdLivro(int idLivro) {
        this.idLivro = idLivro;
    }
    public LocalDate getDataEmprestimo() {
        return dataEmprestimo;
    }
    public void setDataEmprestimo(LocalDate dataEmprestimo) {
        this.dataEmprestimo = dataEmprestimo;
    }
    public LocalDate getDataDevolucao() {
        return dataDevolucao;
    }
    public void setDataDevolucao(LocalDate dataDevolucao) {
        this.dataDevolucao = dataDevolucao;
    }
    public String isDevolvido() {
        return devolvido;
    }
    public void setDevolvido(String devolvido) {
        this.devolvido = devolvido;
    }
//Presença do polimorfismo por Sobreposição
    @Override
    public String toString() {
        return "\nID do Empréstimo: "+idEmp+"\nID do Usuario: "+idUsuario+"\nID do Livro: "+idLivro+
                "\nData da Retirada: "+dataEmprestimo+"\nData da Devolução\n"+dataDevolucao+"\nLivro Devolvido: "+devolvido;
    }
}
