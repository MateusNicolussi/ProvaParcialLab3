//Mateus Martins Nicolussi Cód.:831823
package Biblioteca;
public class Livro {
    //Declarção das Variáveis.
    private int IDLivro;
    private String titulo;
    private String autor;
    private String edicao;
    private String editora;
    private String cidade;
    private int anopublicacao;
    //Criação dos contrutores(Vazio e sobrecarregado)
    public Livro() {
    }
    public Livro(int IDLivro, String titulo, String autor, String edicao, String editora, String cidade, int anopublicacao) {
        this.IDLivro = IDLivro;
        this.titulo = titulo;
        this.autor = autor;
        this.edicao = edicao;
        this.editora = editora;
        this.cidade = cidade;
        this.anopublicacao = anopublicacao;
    }
    //Declaração dos getters e setters
    public int getIDLivro() {
        return IDLivro;
    }
    public void setIDLivro(int IDLivro) {
        this.IDLivro = IDLivro;
    }
    public String getTitulo() {
        return titulo;
    }
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    public String getAutor() {
        return autor;
    }
    public void setAutor(String autor) {
        this.autor = autor;
    }
    public String getEdicao() {
        return edicao;
    }
    public void setEdicao(String edicao) {
        this.edicao = edicao;
    }
    public String getEditora() {
        return editora;
    }
    public void setEditora(String editora) {
        this.editora = editora;
    }
    public String getCidade() {
        return cidade;
    }
    public void setCidade(String cidade) {
        this.cidade = cidade;
    }
    public int getAnopublicacao() {
        return anopublicacao;
    }
    public void setAnopublicacao(int anopublicacao) {
        this.anopublicacao = anopublicacao;
    }
    //Presença do polimorfismo por Sobreposição
    @Override
    public String toString() {
        return "\nID do Livro: "+IDLivro+"\nTítulo: "+titulo+"\nAutor: "+autor+
                "\nEdição: "+edicao+"\nEditora: "+editora+"\nCidade: "+cidade+"\nAno De Publicacao: "+anopublicacao;
    }
}
