//Mateus Martins Nicolussi Cód.:831823
package Biblioteca;
public class Usuario {
    //Declarção das Variáveis.
    private int ID;
    private String nome;
    private String email;
    private String senha;
    //Criação dos contrutores(Vazio e sobrecarregado)
    public Usuario() {
    }
     public Usuario(int ID, String nome, String email, String senha) {
        this.ID = ID;
        this.nome = nome;
        this.email = email;
        this.senha = senha;
    }
     //Declaração dos getters e setters
    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
    //Presença do polimorfismo por Sobreposição
    @Override
    public String toString() {
        return "\nID: "+ID+"\nNome: "+nome+"\nE-mail:¨"+email+"\nSenha: "+senha;
    }
}