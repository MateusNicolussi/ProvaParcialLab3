//Mateus Martins Nicolussi Cód.:831823
package Biblioteca;
//Declaração de Bibliotecas necessárias para o uso da função "Array List<>()"
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;
public class AcervoTeste extends Emprestimo{
    //Declaraçao Variavél de busca
    public static String devolucao = "Sim";
    //Definição de Paramêtro para variável de pesquisa
    
    //Criação da classe de teste
    public static void main(String[] args) {
        //Ciração das Listas dinâmicas a serem utilizadas
        List<Usuario> usuarios = new ArrayList<>();
        List<Livro> livros = new ArrayList<>();
        List<Emprestimo> emprestimos = new ArrayList<>();
        //Inserção de Usuários
        usuarios.add(new Usuario(812344,"Fábio","fabio@unaerp.br","123456"));
        usuarios.add(new Usuario(48725,"Mariana","mariana@unaerp.br","41006"));
        usuarios.add(new Usuario(23244,"Júlia","julia@unaerp.br","526747"));
        usuarios.add(new Usuario(12345,"Otávio","otavio@unaerp.br","654321"));
        usuarios.add(new Usuario(77812,"Sett","sett@unaerp.br","785718"));
        livros.add(new Livro(2431,"Droga da Obediência","Pedro Bandeira","Primeira"
                ,"Moderna","Rio de Janeiro",1984));
        livros.add(new Livro(9872,"Capitães da Areia","Jorge Amado","Trigésima"
                ,"Companhia de Bolso","Rio de Janeiro",1937));
        livros.add(new Livro(31,"O Cortiço","Aluísio Azevedo","Sexta"
                ,"Ética","São Paulo",1978));
        livros.add(new Livro(9814,"Quincas Borba","Machado de Assis","Terceira"
                ,"Ética","São Paulo",1977));
        livros.add(new Livro(7415,"Percy Jackson e o Ladrão de Raios","Rick Riordan","Primeira"
                ,"Intrínseca","Rio de Janeiro",2009));
        emprestimos.add(new Emprestimo(81152,812344,2431,LocalDate.of(2020, Month.MARCH,24),LocalDate.of(2020, Month.MAY,14),"Sim"));
        emprestimos.add(new Emprestimo(0472,12345,9872,LocalDate.of(2020, Month.MAY, 12),LocalDate.now(),"Sim"));
        emprestimos.add(new Emprestimo(852,48725,31,LocalDate.of(2020,Month.MARCH,30),LocalDate.of(2020, Month.MAY, 02),"Sim"));        
        emprestimos.add(new Emprestimo(74182,23244,9814,LocalDate.of(2020, Month.JANUARY,29),LocalDate.of(2020, Month.FEBRUARY,28),"Sim"));
        emprestimos.add(new Emprestimo(0120,77812,7415,LocalDate.of(2020, Month.FEBRUARY, 22),LocalDate.now(),"Sim"));
        //Impressão dos dados implantados nas listas
        usuarios.forEach((f) -> {
            System.out.println(f);
        });
        livros.forEach((f) -> {
            System.out.println(f);
        });
        emprestimos.forEach((f) -> {
            System.out.println(f);
        });
        //Listagem de Livros devolvidos
        emprestimos.forEach((f) -> {
            if(devolucao.equals(devolvido)){
                System.out.println("\n");
                System.out.println(f);
            }
            else{
                System.out.println("\nHá livros com devolução pendente");
            }
            
        });
        //Listagem de Livros não devolvidos
        emprestimos.forEach((f) -> {
            if(!devolucao.equals(devolvido)){
                System.out.println("\n");
                System.out.println(f);
            }
            else{
                System.out.println("\nNão há livros com devolução pendente");
            }
            
        });
        
        
    }
}
